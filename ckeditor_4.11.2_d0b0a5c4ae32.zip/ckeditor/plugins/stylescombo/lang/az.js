﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'az', {
	label: 'Üslub',
	panelTitle: 'Format üslubları',
	panelTitle1: 'Blokların üslubları',
	panelTitle2: 'Sözlərin üslubları',
	panelTitle3: 'Obyektlərin üslubları'
} );
